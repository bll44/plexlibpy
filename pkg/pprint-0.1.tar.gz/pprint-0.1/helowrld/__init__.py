def tryprint():
    return ('it will be oke')