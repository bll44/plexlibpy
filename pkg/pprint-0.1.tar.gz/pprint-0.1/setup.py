from setuptools import setup

setup(name='pprint',
      version='0.1',
      description='The funniest joke in the world',
      url='https://github.com/hamadi15/test',
      author='halim hamadi',
      author_email='halim.hamadi@mail.ugm.ac.id',
      license='MIT',
      packages=['helowrld'],
      zip_safe=False)