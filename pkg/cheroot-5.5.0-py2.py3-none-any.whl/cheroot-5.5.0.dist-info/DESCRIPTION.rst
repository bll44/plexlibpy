.. image:: https://img.shields.io/pypi/v/cheroot.svg
   :target: https://pypi.org/project/cheroot

.. image:: https://img.shields.io/travis/cherrypy/cheroot/master.svg?label=Linux%20build%20%40%20Travis%20CI
   :target: http://travis-ci.org/cherrypy/cheroot

.. image:: https://img.shields.io/appveyor/ci/jaraco/cheroot/master.svg?label=Windows%20build%20%40%20Appveyor
   :target: https://ci.appveyor.com/project/jaraco/cheroot/branch/master

.. image:: https://img.shields.io/pypi/pyversions/cheroot.svg

.. image:: https://img.shields.io/pypi/dm/cheroot.svg

Cheroot is the high-performance, pure-Python HTTP server used by CherryPy.

License
=======

License is indicated in the project metadata (typically one or more
of the Trove classifiers). For more details, see `this explanation
<https://github.com/jaraco/skeleton/issues/1>`_.

Status
======

The test suite is currently disabled. Currently, the only way to validate the test
suite is to run it against CherryPy.


